require("dotenv").config()
const express = require("express")
const cors = require("cors")
const multer = require("multer")
const unzipper = require("unzipper")
const fs = require("fs-extra")
const path = require("path")

const app = express()
const upload = multer({ dest: "uploads/" })

app.use(cors())
app.use(express.json())

app.get("/health", (req, res) => {
  res.json({ status: "Backend running ✅" })
})

app.post("/upload", upload.single("zipFile"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" })
    }

    const zipPath = req.file.path
    const extractPath = path.join(__dirname, "extracted")

    await fs.remove(extractPath)
    await fs.ensureDir(extractPath)

    await fs.createReadStream(zipPath)
      .pipe(unzipper.Extract({ path: extractPath }))
      .promise()

    res.json({ message: "ZIP extracted successfully ✅" })

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Upload failed" })
  }
})

app.listen(5000, () => {
  console.log("Server running on port 5000")
})